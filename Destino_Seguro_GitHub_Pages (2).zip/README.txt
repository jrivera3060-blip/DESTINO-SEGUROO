DESTINO SEGURO - GITHUB PAGES

1. Crea un repositorio público llamado destino-seguro.
2. Sube directamente estos archivos a la raíz:
   index.html
   style.css
   script.js
3. En GitHub entra a Settings > Pages.
4. En Build and deployment selecciona:
   Source: Deploy from a branch
   Branch: main
   Folder: / (root)
5. Pulsa Save.
6. Espera unos minutos y abre la dirección que GitHub te mostrará.

Es un prototipo escolar: el mapa y las rutas son ilustrativos y no sustituyen información oficial de emergencia.
