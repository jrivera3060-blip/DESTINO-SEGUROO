const screens=document.querySelectorAll(".screen"),toast=document.getElementById("toast");
function go(id){screens.forEach(s=>s.classList.remove("active"));document.getElementById(id)?.classList.add("active");scrollTo(0,0)}
document.querySelectorAll("[data-go]").forEach(b=>b.addEventListener("click",()=>go(b.dataset.go)));
document.getElementById("topMenu").onclick=()=>go("menu");
function msg(t){toast.textContent=t;toast.classList.add("show");clearTimeout(window.tt);window.tt=setTimeout(()=>toast.classList.remove("show"),2600)}
document.getElementById("searchBtn").onclick=()=>{let d=document.getElementById("destination").value.trim();if(!d)return msg("Escribe un destino para buscar una ruta.");msg("Buscando ruta segura hacia "+d+"...");setTimeout(()=>go("ruta"),600)};
document.getElementById("destination").onkeydown=e=>{if(e.key==="Enter")document.getElementById("searchBtn").click()};
document.getElementById("startRoute").onclick=()=>msg("Ruta iniciada. Evita las zonas de riesgo.");
addEventListener("offline",()=>{msg("Sin internet: consulta la información guardada.");setTimeout(()=>go("offline"),400)});
addEventListener("online",()=>msg("Conexión recuperada."));